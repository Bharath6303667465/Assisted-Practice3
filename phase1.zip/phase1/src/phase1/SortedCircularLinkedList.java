package phase1;

public class SortedCircularLinkedList {
    static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node insert(Node head, int data) {
        Node newNode = new Node(data);

        // If the list is empty, make newNode the head and point to itself
        if (head == null) {
            newNode.next = newNode;
            return newNode;
        }

        // If newNode should be inserted before the head
        if (data < head.data) {
            newNode.next = head;

            // Find the last node in the list
            Node last = head;
            while (last.next != head) {
                last = last.next;
            }

            // Update the last node to point to newNode
            last.next = newNode;

            // Update the head to newNode
            return newNode;
        }

        // Find the node after which newNode should be inserted
        Node current = head;
        while (current.next != head && current.next.data < data) {
            current = current.next;
        }

        // Insert newNode after current
        newNode.next = current.next;
        current.next = newNode;

        return head;
    }

    static void displayCircularLinkedList(Node head) {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = null;

        // Inserting elements into the sorted circular linked list
        head = insert(head, 4);
        head = insert(head, 2);
        head = insert(head, 6);
        head = insert(head, 8);
        head = insert(head, 5);

        System.out.println("Sorted Circular Linked List:");
        displayCircularLinkedList(head);
    }
}

