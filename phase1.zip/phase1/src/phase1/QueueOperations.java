package phase1;

import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);

        System.out.println("Queue elements: " + queue);

        // Remove elements from the queue
        int removedElement = queue.poll();
        System.out.println("Removed element: " + removedElement);

        System.out.println("Queue elements after removal: " + queue);
    }
}

