package phase1;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] list = {10, 2, 8, 4, 1, 6, 9, 3, 7, 5};
        
        int fourthSmallest = findFourthSmallest(list);
        
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
    
    public static int findFourthSmallest(int[] list) {
        if (list.length < 4) {
            throw new IllegalArgumentException("List size should be at least 4");
        }
        
        // Sort the list in ascending order
        Arrays.sort(list);
        
        // Return the fourth element
        return list[3];
    }
}
