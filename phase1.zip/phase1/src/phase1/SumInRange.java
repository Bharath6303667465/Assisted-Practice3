package phase1;

public class SumInRange {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        var n = arr.length;
        int L = 2; // Starting index
        int R = 7; // Ending index
        
        int sum = calculateSum(arr, L, R);
        
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }
    
    public static int calculateSum(int[] arr, int L, int R) {
        int sum = 0;
        
        if (L < 0 || R >= arr.length || L > R) {
            throw new IllegalArgumentException("Invalid range");
        }
        
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        
        return sum;
    }
}

