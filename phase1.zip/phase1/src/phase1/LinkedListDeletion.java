package phase1;

public class LinkedListDeletion {
    static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
        }
    }

    static Node deleteFirstOccurrence(Node head, int key) {
        if (head == null) {
            return null;
        }

        // If the key is present at the head
        if (head.data == key) {
            return head.next;
        }

        Node prev = head;
        Node curr = head.next;

        // Traverse the list to find the key
        while (curr != null && curr.data != key) {
            prev = curr;
            curr = curr.next;
        }

        // If the key is found, delete the node
        if (curr != null) {
            prev.next = curr.next;
        }

        return head;
    }

    static void displayLinkedList(Node head) {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);

        head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;

        System.out.println("Linked list before deletion:");
        displayLinkedList(head);

        int key = 3;
        head = deleteFirstOccurrence(head, key);

        System.out.println("Linked list after deleting first occurrence of " + key + ":");
        displayLinkedList(head);
    }
}

