package phase1;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int rotateSteps = 5;

        System.out.println("Original Array:");
        printArray(arr);

        rightRotate(arr, rotateSteps);

        System.out.println("Array after right rotation:");
        printArray(arr);
    }

    public static void rightRotate(int[] arr, int steps) {
        int length = arr.length;
        int[] temp = new int[length];

        // Copy the elements to a temporary array
        System.arraycopy(arr, 0, temp, 0, length);

        // Perform right rotation
        for (int i = 0; i < length; i++) {
            arr[(i + steps) % length] = temp[i];
        }
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

